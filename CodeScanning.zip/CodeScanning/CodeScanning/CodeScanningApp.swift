//
//  CodeScanningApp.swift
//  CodeScanning
//
//  Created by Katherine Nguyen on 1/5/2024.
//

import SwiftUI

@main
struct CodeScanningApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
