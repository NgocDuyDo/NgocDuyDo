//
//  MedicationLogView.swift
//  assignment3
//
//  Created by Chohwi Park on 29/4/2024.
//

import SwiftUI

struct MedicationLogView: View {
    @StateObject var viewModel = MedicationViewModel()
    @State private var showingMedicationDetail = false
    @State private var addMecation = false
    var body: some View {
        NavigationView {
            VStack {
            //
            }
        }
    }
}
