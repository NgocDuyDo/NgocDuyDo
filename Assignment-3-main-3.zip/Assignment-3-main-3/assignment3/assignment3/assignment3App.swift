//
//  assignment3App.swift
//  assignment3
//
//  Created by Chohwi Park on 22/4/2024.
//

import SwiftUI

@main
struct assignment3App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
