//
//  MedicationViewModel.swift
//  assignment3
//
//  Created by Chohwi Park on 29/4/2024.
//

import Foundation
class MedicationViewModel: ObservableObject {
    
}
